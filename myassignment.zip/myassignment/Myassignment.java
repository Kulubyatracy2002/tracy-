package myassignment;

public class Myassignment {

	public static void main(String[] args) {

		for(int i=2; i<=6; i++ );
		System.out.println();
		
		int count = 1;
		do {
			System.out.println("count:"+ count );
			count++;
		} while(count<=5);
		
		int w=2;
		while(w<=6);{
			System.out.println(w);
			w++;
		}
	}
	
	
	
	

}
